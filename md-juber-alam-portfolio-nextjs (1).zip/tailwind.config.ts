import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}", "./data/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { ink: "#07111f", cyanx: "#22d3ee" }, boxShadow: { glow: "0 0 50px rgba(34,211,238,.12)" } } },
  plugins: []
};
export default config;
