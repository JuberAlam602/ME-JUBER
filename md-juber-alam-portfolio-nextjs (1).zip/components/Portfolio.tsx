 "use client";
import { useState } from "react";
import { Moon, Sun, Menu, X, ArrowUpRight, Github, Linkedin, Mail, Phone, MapPin, Download, Printer, ExternalLink, Search, GraduationCap, Code2, Award, Briefcase, Images, Send } from "lucide-react";
import { site, education, semesters, skills, projects, certificates, institutions, internships } from "@/data/site";

const nav = ["Home","About","Education","Academic Performance","Institutions","Skills","Projects","Internships","Certificates","Achievements","Resume","Gallery","Contact"];

export default function Portfolio(){
  const [dark,setDark]=useState(false), [open,setOpen]=useState(false), [filter,setFilter]=useState("All"), [query,setQuery]=useState("");
  const certs=certificates.filter(c=>c.toLowerCase().includes(query.toLowerCase()) && (filter==="All" || filter==="All"));
  return <div className={dark?"dark":""}>
    <header className="fixed top-0 z-50 w-full border-b" style={{background:"color-mix(in srgb, var(--bg) 88%, transparent)",borderColor:"var(--line)",backdropFilter:"blur(18px)"}}>
      <div className="container flex h-16 items-center justify-between">
        <a href="#Home" className="font-black text-xl"><span className="gradient-text">J</span>uber<span className="gradient-text">.</span></a>
        <nav className="hidden xl:flex gap-5 text-sm" style={{color:"var(--muted)"}}>{nav.map(n=><a key={n} href={"#"+n} className="hover:opacity-70">{n}</a>)}</nav>
        <div className="flex items-center gap-2"><button aria-label="Toggle theme" className="p-2 rounded-xl glass" onClick={()=>setDark(!dark)}>{dark?<Sun size={18}/>:<Moon size={18}/>}</button><button className="xl:hidden p-2 rounded-xl glass" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></div>
      </div>
      {open&&<div className="xl:hidden container pb-4 grid gap-2">{nav.map(n=><a onClick={()=>setOpen(false)} key={n} href={"#"+n} className="p-2 rounded-lg glass">{n}</a>)}</div>}
    </header>

    <main>
      <section id="Home" className="section pt-36 hero-bg min-h-[90vh] flex items-center">
        <div className="container grid lg:grid-cols-[1.2fr_.8fr] gap-12 items-center">
          <div className="fade-up">
            <div className="inline-flex items-center gap-2 rounded-full px-4 py-2 glass text-sm mb-6"><span className="w-2 h-2 rounded-full bg-cyan-400"></span>Available for online & offline opportunities</div>
            <p className="uppercase tracking-[.25em] text-sm" style={{color:"var(--muted)"}}>{site.location}</p>
            <h1 className="mt-4 text-5xl sm:text-7xl font-black tracking-tight">{site.name}<br/><span className="gradient-text">{site.headline}</span></h1>
            <p className="mt-6 max-w-2xl text-lg leading-8" style={{color:"var(--muted)"}}>{site.bio}</p>
            <div className="flex flex-wrap gap-3 mt-8">
              <a href="#Resume" className="px-5 py-3 rounded-xl bg-sky-600 text-white font-semibold flex gap-2 items-center">View Resume <ArrowUpRight size={17}/></a>
              <a href="#Projects" className="px-5 py-3 rounded-xl glass font-semibold">View Projects</a>
              <a href="#Contact" className="px-5 py-3 rounded-xl glass font-semibold">Contact Me</a>
            </div>
            <div className="flex gap-5 mt-8" style={{color:"var(--muted)"}}><a href={site.github} target="_blank"><Github/></a><a href={site.linkedin} target="_blank"><Linkedin/></a><a href={"mailto:"+site.email}><Mail/></a></div>
          </div>
          <div className="glass rounded-[2rem] p-8 relative overflow-hidden">
            <div className="absolute -right-20 -top-20 w-52 h-52 rounded-full bg-cyan-400/10 blur-3xl"/>
            <div className="text-sm" style={{color:"var(--muted)"}}>PROFILE SNAPSHOT</div>
            <div className="mt-6 grid grid-cols-2 gap-4">{[["B.Tech","CSE"],["CGPA","See semesters"],["Base","Madhubani"],["Year","2026"]].map(([a,b])=><div key={a} className="rounded-2xl border p-5" style={{borderColor:"var(--line)"}}><div className="text-sm" style={{color:"var(--muted)"}}>{a}</div><div className="font-bold mt-2">{b}</div></div>)}</div>
          </div>
        </div>
      </section>

      <Section id="About" title="About me" kicker="PROFILE"><div className="grid lg:grid-cols-2 gap-6"><Card><h3 className="text-2xl font-bold">Professional summary</h3><p className="mt-4 leading-8" style={{color:"var(--muted)"}}>{site.bio}</p><p className="mt-4 leading-8" style={{color:"var(--muted)"}}><b>Career objective:</b> {site.objective}</p></Card><Card><h3 className="text-2xl font-bold">Developer profile</h3><div className="grid sm:grid-cols-2 gap-4 mt-5">{[["Full name",site.name],["Education",site.role],["Technical interests","Web development, UI, APIs, databases"],["Career goal","Build practical, reliable software products"]].map(([a,b])=><div key={a} className="p-4 rounded-2xl bg-black/5 dark:bg-white/5"><small style={{color:"var(--muted)"}}>{a}</small><div className="mt-1 font-semibold">{b}</div></div>)}</div></Card></div></Section>

      <Section id="Education" title="Education" kicker="ACADEMIC JOURNEY"><div className="grid-auto">{education.map((e:any,i)=><Card key={e.level}><div className="flex justify-between"><span className="text-sm px-3 py-1 rounded-full bg-sky-500/10 text-sky-600">{e.level}</span><GraduationCap/></div><h3 className="text-xl font-bold mt-5">{e.institution||e.university}</h3><p className="mt-2" style={{color:"var(--muted)"}}>{e.course||e.board} {e.stream?`• ${e.stream}`:""} {e.branch?`• ${e.branch}`:""}</p><div className="mt-6 text-3xl font-black gradient-text">{e.percentage}</div><div className="mt-3 text-sm" style={{color:"var(--muted)"}}>Passing year: {e.year} • {e.location||e.campus}</div></Card>)}</div>
        <div className="glass rounded-3xl p-6 mt-6 overflow-x-auto"><h3 className="text-xl font-bold mb-4">Semester-wise CGPA</h3><table className="w-full text-left min-w-[650px]"><thead><tr style={{color:"var(--muted)"}}>{semesters.map(([s])=><th key={s} className="p-3">{s}</th>)}</tr></thead><tbody><tr>{semesters.map(([s,v])=><td key={s} className="p-3 font-bold">{v}</td>)}</tr></tbody></table></div>
      </Section>

      <Section id="Academic Performance" title="Academic performance" kicker="DASHBOARD"><div className="grid-auto">{[["10th","67%"],["12th","76%"],["Graduation","87%"]].map(([a,b])=><Card key={a}><div className="text-sm" style={{color:"var(--muted)"}}>{a}</div><div className="text-5xl font-black mt-3 gradient-text">{b}</div><div className="mt-5 h-2 rounded-full bg-slate-200 dark:bg-slate-800"><div className="h-2 rounded-full bg-sky-500" style={{width:b}}/></div></Card>)}</div></Section>

      <Section id="Institutions" title="Institutions" kicker="ACADEMIC HISTORY"><div className="grid-auto">{institutions.map(x=><Card key={x.name}><h3 className="font-bold text-xl">{x.name}</h3><p className="mt-3" style={{color:"var(--muted)"}}>{x.address}<br/>{x.city}, {x.state}</p><div className="mt-5 space-y-2 text-sm"><div><b>Qualification:</b> {x.qualification}</div><div><b>Study period:</b> {x.period}</div><div><b>Official website:</b> {x.website}</div><div><b>Courses/programs:</b> [Editable placeholder]</div><div><b>About:</b> [Editable official information placeholder]</div></div><button className="mt-5 px-4 py-2 rounded-xl glass flex items-center gap-2">Map / Location <MapPin size={16}/></button></Card>)}</div></Section>

      <Section id="Skills" title="Technical skills" kicker="TOOLKIT"><div className="grid-auto">{skills.map(([a,b])=><Card key={a}><Code2 className="text-sky-500"/><h3 className="font-bold mt-5">{a}</h3><p className="mt-2 text-sm leading-6" style={{color:"var(--muted)"}}>{b}</p></Card>)}</div></Section>

      <Section id="Projects" title="Selected projects" kicker="BUILDING"><div className="grid-auto">{projects.map(p=><Card key={p.title}><div className="h-36 rounded-2xl border flex items-center justify-center mb-5" style={{borderColor:"var(--line)"}}><Images size={34} style={{color:"var(--muted)"}}/><span className="ml-2 text-sm" style={{color:"var(--muted)"}}>Project screenshot placeholder</span></div><h3 className="text-xl font-bold">{p.title}</h3><p className="mt-2" style={{color:"var(--muted)"}}>{p.description}</p><p className="mt-4 text-sm font-semibold">{p.tech}</p><ul className="mt-3 space-y-1 text-sm" style={{color:"var(--muted)"}}>{p.features.map(f=><li key={f}>• {f}</li>)}</ul><div className="flex gap-2 mt-5"><a className="px-3 py-2 rounded-lg glass text-sm flex gap-2" href={site.github}><Github size={15}/> GitHub</a><button className="px-3 py-2 rounded-lg glass text-sm flex gap-2"><ExternalLink size={15}/> Live Demo</button></div></Card>)}</div></Section>

      <Section id="Internships" title="Internship timeline" kicker="EXPERIENCE"><div className="space-y-5">{internships.map(i=><Card key={i.organization}><div className="grid md:grid-cols-[.8fr_1.2fr] gap-6"><div><Briefcase className="text-sky-500"/><h3 className="text-xl font-bold mt-4">{i.organization}</h3><p className="mt-2" style={{color:"var(--muted)"}}>{i.role} • {i.duration}</p></div><div className="space-y-2" style={{color:"var(--muted)"}}><p><b>Technologies:</b> {i.technologies}</p><p><b>Responsibilities:</b> {i.responsibilities}</p><p><b>Certificate:</b> {i.certificate}</p><p><b>Project:</b> {i.project}</p></div></div></Card>)}</div></Section>

      <Section id="Certificates" title="Certificate gallery" kicker="CREDENTIALS"><div className="flex flex-wrap gap-3 mb-6"><div className="relative"><Search className="absolute left-3 top-3" size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search certificates..." className="pl-10 pr-4 py-3 rounded-xl glass outline-none"/></div>{["All","Web Development","Internship","Training","Technical Skills"].map(f=><button key={f} onClick={()=>setFilter(f)} className={"px-4 py-3 rounded-xl glass "+(filter===f?"ring-2 ring-sky-400":"")}>{f}</button>)}</div><div className="grid-auto">{certs.map(c=><Card key={c}><div className="h-40 rounded-2xl border flex items-center justify-center" style={{borderColor:"var(--line)"}}><Award size={36} className="text-sky-500"/></div><h3 className="font-bold mt-4">{c}</h3><p className="text-sm mt-1" style={{color:"var(--muted)"}}>Certificate title / date placeholder</p><div className="flex gap-2 mt-4"><button className="px-3 py-2 rounded-lg glass text-sm">View Certificate</button><button className="px-3 py-2 rounded-lg glass text-sm"><Download size={14} className="inline"/> Download</button></div></Card>)}</div></Section>

      <Section id="Achievements" title="Achievements & activities" kicker="HIGHLIGHTS"><div className="grid-auto">{["Academic achievements","Certifications","Training","Competitions","Industrial visits","Technical activities"].map(x=><Card key={x}><Award className="text-sky-500"/><h3 className="font-bold mt-4">{x}</h3><p className="mt-2 text-sm" style={{color:"var(--muted)"}}>[Add verified achievement details here]</p></Card>)}</div></Section>

      <Section id="Resume" title="Resume" kicker="PROFESSIONAL DOCUMENT"><Card><div className="grid lg:grid-cols-[1fr_auto] gap-8 items-center"><div><h3 className="text-2xl font-bold">{site.name}</h3><p className="mt-2" style={{color:"var(--muted)"}}>{site.role} • {site.headline}</p><p className="mt-4 max-w-2xl" style={{color:"var(--muted)"}}>A clean online resume section. Place your final PDF at <code>/public/resume.pdf</code> to enable the download button.</p></div><div className="flex flex-wrap gap-2"><a href="/resume.pdf" className="px-4 py-3 rounded-xl bg-sky-600 text-white flex gap-2 items-center"><Download size={17}/> Download PDF</a><button onClick={()=>window.print()} className="px-4 py-3 rounded-xl glass flex gap-2 items-center"><Printer size={17}/> Print Resume</button></div></div></Card></Section>

      <Section id="Gallery" title="Gallery" kicker="VISUAL JOURNEY"><div className="grid grid-cols-2 md:grid-cols-3 gap-4">{["Professional photo","Certificate","College event","Project","Activity","Training"].map((x,i)=><div key={x} className="glass rounded-3xl h-48 flex items-center justify-center overflow-hidden relative"><div className="absolute inset-0 bg-gradient-to-br from-sky-500/15 to-cyan-400/5"/><div className="text-center relative"><Images className="mx-auto text-sky-500"/><p className="mt-3 font-semibold">{x}</p><small style={{color:"var(--muted)"}}>Image placeholder {i+1}</small></div></div>)}</div></Section>

      <Section id="Contact" title="Let's connect" kicker="CONTACT"><div className="grid lg:grid-cols-2 gap-6"><Card><h3 className="text-2xl font-bold">Contact details</h3><div className="mt-6 space-y-5">{[[Mail,site.email,"Email"],[Phone,site.phone,"Phone"],[MapPin,site.location,"Location"]].map(([I,v,l]:any)=><div key={l} className="flex gap-4"><I className="text-sky-500"/><div><div className="text-sm" style={{color:"var(--muted)"}}>{l}</div><div className="font-semibold break-all">{v}</div></div></div>)}</div></Card><Card><form onSubmit={e=>e.preventDefault()} className="space-y-4"><input defaultValue={site.name} placeholder="Name" className="w-full p-4 rounded-xl glass outline-none"/><input defaultValue={site.email} placeholder="Email" type="email" className="w-full p-4 rounded-xl glass outline-none"/><input defaultValue={site.role} placeholder="Subject" className="w-full p-4 rounded-xl glass outline-none"/><textarea placeholder="Message" rows={6} className="w-full p-4 rounded-xl glass outline-none"/><button className="px-5 py-3 rounded-xl bg-sky-600 text-white font-semibold flex items-center gap-2"><Send size={17}/> Send Message</button></form></Card></div></Section>
    </main>
    <footer className="border-t py-8" style={{borderColor:"var(--line)"}}><div className="container flex flex-col md:flex-row gap-3 justify-between text-sm" style={{color:"var(--muted)"}}><div><b style={{color:"var(--text)"}}>{site.name}</b> • {site.role}</div><div>© 2026 {site.name}. All Rights Reserved.</div></div></footer>
  </div>
}

function Section({id,title,kicker,children}:{id:string,title:string,kicker:string,children:React.ReactNode}){return <section id={id} className="section"><div className="container"><div className="mb-10"><div className="text-sm tracking-[.25em] text-sky-600 font-bold">{kicker}</div><h2 className="section-title mt-3">{title}</h2></div>{children}</div></section>}
function Card({children}:{children:React.ReactNode}){return <div className="glass rounded-3xl p-6 hover:-translate-y-1 transition-transform duration-300">{children}</div>}
