export const site = {
  name: "Md Juber Alam",
  shortName: "Juber Alam",
  role: "B.Tech Computer Science & Engineering",
  headline: "Frontend / Full Stack Developer",
  location: "Mauahi Bhatsimar, Rajanagar, Madhubani, Bihar 847235",
  email: "MDJUBERALAM602@GMAIL.COM",
  phone: "6203560210",
  linkedin: "https://www.linkedin.com/in/md-juber-alam-90b2692aa/",
  github: "https://github.com/JuberAlam602",
  graduationYear: "2026",
  bio: "Computer Science & Engineering graduate focused on building responsive, accessible and practical web applications with modern frontend and full-stack technologies.",
  objective: "To build reliable, user-focused software products while continuously strengthening my engineering, problem-solving and collaboration skills."
};

export const education = [
  { level: "10th", percentage: "67%", board: "BSEB", institution: "U.M.S BARHARA RAJNAGAR MADHUBANI", year: "2019", location: "BARHARA RAJNAGAR" },
  { level: "12th", percentage: "76%", board: "BSEB", institution: "K.S COLLEGE LAHERIYASARAI DARBHANGA", stream: "SCIENCE", year: "2021", location: "DARBHANGA" },
  { level: "B.Tech", percentage: "87%", course: "Bachelor of Technology", branch: "Computer Science & Engineering", university: "Sandip University", campus: "Sijoul, Madhubani, Bihar", year: "2026" }
];

export const semesters = [
  ["Semester 1", 9.16], ["Semester 2", 9.14], ["Semester 3", 9.35], ["Semester 4", 8.95],
  ["Semester 5", 9.09], ["Semester 6", 9.03], ["Semester 7", 9.06], ["Semester 8", 8.30]
];

export const skills = [
  ["React.js", "Component-based interfaces and reusable UI."], ["Next.js", "Modern React applications and SEO-ready pages."],
  ["Tailwind CSS", "Responsive utility-first UI development."], ["Node.js", "Backend JavaScript and API development."],
  ["TypeScript", "Type-safe, maintainable application code."], ["Git", "Version control and collaborative workflows."],
  ["GitHub", "Source control, repositories and project collaboration."], ["Postman", "API testing and development workflows."],
  ["MongoDB", "Document-oriented database fundamentals."], ["AI Tools", "Practical AI-assisted development workflows."],
  ["Web Development", "Responsive frontend and full-stack project development."]
];

export const projects = [
  { title: "Library Management System", description: "Web application for managing students, books, issues, returns and feedback.", tech: "HTML • CSS • JavaScript • PHP • SQL", features: ["Book management", "Student registration", "Issue / return workflow"] },
  { title: "Online Quiz App", description: "Interactive quiz experience with question navigation and result presentation.", tech: "HTML • CSS • JavaScript", features: ["Quiz UI", "Score calculation", "Responsive layout"] },
  { title: "Shopping Website", description: "Responsive shopping interface designed around product discovery and clean navigation.", tech: "HTML • CSS • JavaScript", features: ["Product cards", "Responsive UI", "Cart-ready structure"] },
  { title: "Cyber Cafe Website", description: "Professional service website concept for cyber cafe and digital services.", tech: "HTML • CSS • JavaScript", features: ["Service listing", "Contact section", "Mobile-friendly UI"] }
];

export const certificates = [
  "IBM SkillsBuild", "OctaNet", "Internship Studio", "ExcelR", "My Bharat", "Unstop", "C-DAC", "Zidio", "Mithila Stack"
];

export const institutions = [
  { name: "U.M.S BARHARA RAJNAGAR MADHUBANI", address: "[Add exact official address]", city: "Madhubani", state: "Bihar", period: "2019", qualification: "10th", website: "[Official website placeholder]" },
  { name: "K.S COLLEGE LAHERIYASARAI DARBHANGA", address: "[Add exact official address]", city: "Darbhanga", state: "Bihar", period: "2021", qualification: "12th Science", website: "[Official website placeholder]" },
  { name: "Sandip University", address: "[Add exact official campus address]", city: "Sijoul, Madhubani", state: "Bihar", period: "B.Tech • 2022–2026", qualification: "B.Tech CSE", website: "[Official website placeholder]" }
];

export const internships = [
  { organization: "C-DAC Patna", role: "Frontend Developer / Summer Training", duration: "4 weeks", technologies: "Web Development", responsibilities: "Training/project details can be edited here.", certificate: "Certificate placeholder", project: "Project placeholder" },
  { organization: "Skill Darpan / Diptech Technology Pvt. Ltd.", role: "Internship", duration: "1 month", technologies: "Editable", responsibilities: "Internship responsibilities placeholder.", certificate: "Certificate placeholder", project: "Project placeholder" }
];
