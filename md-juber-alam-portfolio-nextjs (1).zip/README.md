# Md Juber Alam — Premium Portfolio

## Run
1. Install Node.js 20+.
2. `npm install`
3. `npm run dev`
4. Open `http://localhost:3000`

## Edit personal data
Update `data/site.ts`. All main personal/academic/project/certificate data is centralized there.

## Resume
Put the final PDF at `public/resume.pdf`.

## Images
Replace the visual placeholders in `components/Portfolio.tsx` with `next/image` assets under `public/images/` when exact photos/certificates are available.

## Important
Institution facts, certificate dates, official URLs, achievements and other unknown details intentionally remain placeholders and should be replaced with verified information.
