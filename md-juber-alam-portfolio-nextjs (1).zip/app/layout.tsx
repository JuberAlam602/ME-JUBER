import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Md Juber Alam | B.Tech CSE | Developer Portfolio",
  description: "Professional digital biodata, academic portfolio, resume, certificate portfolio and developer portfolio of Md Juber Alam.",
  keywords: ["Md Juber Alam", "B.Tech CSE", "Sandip University", "Frontend Developer", "Full Stack Developer", "Madhubani"],
  openGraph: {
    title: "Md Juber Alam | Developer Portfolio",
    description: "B.Tech CSE digital biodata and developer portfolio.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}